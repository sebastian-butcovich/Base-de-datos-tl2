package controlador;
import	java.util.Scanner;
import	Vista.Menu;
public class Principal {
	public static void main(String[]args)
	{
		Scanner in = new Scanner(System.in);
		System.out.println("BIENVENIDO AL PROGRAMA!!!");
		if(Menu.pantallaConexion(in))
		{
			Menu.menu(in);
			if(consultas.cerrarConexion())
			{
				System.out.println("Se cerro la conexion exitosamente");
			}
			else {
				System.out.println("Fallo al cerrar la conexion");
			}
			
		}
		System.out.println("FIN");
	}
	
}
