package controlador;
import	java.sql.*;
public class conexion {
	private static Connection conexion;
	public conexion()
	{
	}
	public  static Connection getConexion(String url,String userName,String password)
	{
		if (conexion != null)
		{
			return conexion;
		}
		else {
			try {
			conexion = DriverManager.getConnection(url,userName,password);
			}catch(Exception e)
			{
				e.getStackTrace();
			}
		}		
		return conexion;
	}
	public static boolean cerrarConexion()
	{
		try {
			conexion.close();
			return true;
		}catch(SQLException e)
		{
			e.getStackTrace();
		}
		return false;
	}
	
}
