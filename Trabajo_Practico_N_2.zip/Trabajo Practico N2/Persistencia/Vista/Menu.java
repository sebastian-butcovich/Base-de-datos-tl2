package Vista;

import java.util.Scanner;

import javax.swing.JOptionPane;

import controlador.consultas;
import modelo.Futbolista;
import modelo.Pais;
import modelo.Sede;

public class Menu {
	public static void menu(Scanner in)
	{
		if(iniciar(in) != 0)
		{
			menu(in);
		}
	}
	public static int iniciar(Scanner in)
	{
		int respuesta;
		mostrarMenuChico();
		respuesta = interactuarMenuChico( in);
		return respuesta;
	}
	public static boolean pantallaConexion(Scanner in)
	{
		boolean c ;
		System.out.println("Ingrese nombre de la base, usuario y contraseña ");
		System.out.println("");;
		System.out.print(" nombre de la base de datos: ");
		String url = in.next();
		System.out.println("");
		System.out.print("Ingrese el nombre de usuario de la cuenta: ");
		String userName = in.next();
		System.out.println("");
		System.out.print("Ingrese la contraseña: ");
		String password = in.next();
		c = consultas.establecerConexion(url,userName, password);
		if(c == false)
		{
			System.out.print("Desea volver a intentarlo ingres `si` o `no` ");
			String rta = in.next();
			if(rta.equals("si")) {
				c = pantallaConexion(in);
			}
			return c;
		}else
			return true;
		
	}
	public static void mostrarMenuChico()
	{
		System.out.println("");
		System.out.println("1: Mostrar acciones ");
		System.out.println("2: Salir");
		System.out.println("");
		System.out.print(" Esperando respuesta: ");
	}
	public static int interactuarMenuChico(Scanner in)
	{
			int respuesta = in.nextInt();
			if(respuesta != 1)
			{
				System.out.println( "Termino el programa, la base de datos se cerrara automaticamente! Que tenga un buen dia ");
				respuesta = 0;
			}else
			{
				mostrarMenu();
				interactuarConElMenu(in);
			}
			return respuesta;
	}
	public static void mostrarMenu()
	{
		System.out.println();
		System.out.println();
		System.out.println();
		System.out.println("Se muestra el menu con las opciones");
		System.out.println("1 : Mostrar Tabla futbolista            6 : Ingresar una nueva sede           Informacion : Se estabelcio una conexion con una base de ");
		System.out.println("2 : Mostrar Tabla sede                  7 : Eliminar un futbolista            datos corriendo en esta maquina, usted va a poder operar");
		System.out.println("3 : Mostrar Tabla pais                  8 : Eliminar un pais                  con los siguientes comandos, una vez terminado el programa,");
		System.out.println("4 : Ingresar un nuevo futbolista        9 : Eliminar una sede                 la conexion se cerrara automaticamente");
		System.out.println("5 : Ingresar un nuevo pais              10 : Actualizar un sede ");
		System.out.println("");
		System.out.println("0 : Volver al munu chico");
		System.out.println("");
		System.out.print("Esperando respuesta : ");
	}
	public static boolean interactuarConElMenu(Scanner in)
	{
		boolean estado = true;
		String respuesta = in.next();
		switch(respuesta)
		{
		case "1":
			mostrarTablaFutbolista();
			break;
		case "2":
			mostrarTablaSede();
			break;
		case "3":
			mostrarTablaPais();
			break;
		case "4":
			cargarFutbolista(in);
			break;
		case "5":
			cargarPais(in);
			break;
		case "6":
			cargarSede(in);
			break;
		case "7":
			eliminarFutbolista(in);
			break;
		case "8":
			eliminarPais(in);
			break;
		case "9":
			eliminarSede(in);
			break;
		case "10":
			actualizarSede(in);
			break;
		case "0":
			estado = false;
			break;
		default :
			JOptionPane.showMessageDialog(null, "Intruccion equivocada, salio del menu ");
			break;
		}
	
		return estado;
	}
	public static void actualizarSede(Scanner in)
	{
		mostrarTablaSede();
		System.out.print("Escriba el nombre de la sede que desea modificar ");
		String sedeVieja = in.next();
		System.out.print("Ingrese los parametros nuevos de la sede ");
		System.out.println("");
		System.out.print(" Ingrese el nombre de la sede ");
		String nombre = in.next();
		System.out.print(" Ingrese la cantidad de personas que entran en la sede ");
		int cantidad = in.nextInt();
		System.out.println(" se muestra los paises en forma de recordatorio  ");
		mostrarTablaPais();
		System.out.print(" Ingrese el id del pais al que pertenece  ");
		int idPais = in.nextInt();
		consultas.actualizarSede(nombre,cantidad,idPais,sedeVieja);
	}
	public static void eliminarSede(Scanner in)
	{
		mostrarTablaSede();
		System.out.print("Ingrese el id de la sede que desea eliminar ");
		int id = in.nextInt();
		if(consultas.eliminarSede(id)) {
			System.out.println("Se elimino la sede correctamente");
		}
		else
		{
			System.out.println("algo fallo al momento de eliminar la sede");
		}
		
	}
	public static void eliminarPais(Scanner in)
	{
		mostrarTablaPais();
		System.out.print("Ingrese el id del pais que desea eliminar ");
		int id = in.nextInt();
		System.out.println("Esta seguro de eliminar el pais, cuando lo elimine tambien se perderan los jugadores y sedes que pertenescan a el ");
		System.out.println("Ingrese `si `para confirmar `no` para negar");
		String rta = in.next();
		if(rta.equals("si")) {
			consultas.eliminarPais(id);
			System.out.println("se elimino el pais, los futbolistas y la sedes que pertenecen a el");
		}else
		{
			System.out.println("no se elimino");
		}
	}
	public static void eliminarFutbolista(Scanner in)
	{
		mostrarTablaFutbolista();
		System.out.print("Escriba el id del futbolista que desea eliminar ");
		int id = in.nextInt();
		if(consultas.eliminarFutbolista(id)) {
			System.out.println("El futbolista se elimino exitosamente");
		}else
		{
			System.out.println("algo fallo al intentar eliminar al futbolista");
		}
	}
	public static void cargarFutbolista(Scanner in)
	{
		Futbolista f =cargarDatosFutbolista(in);
		if(f != null) {
			consultas.ingresarFutbolista(f);
			System.out.println("EL FUTBOLISTA SE CARGO");
		}
		else {
			System.out.println("Los datos no eran correctos");
		}
	}
	public static void cargarSede(Scanner in)
	{
		Sede s =cargarDatosSede(in);
		if(consultas.verificarQueLaSedeNoExista(s.getNombre()))
		{
			consultas.ingresarSede(s);
			System.out.println("SE CARGO EXITOSAMENTE LA SEDE EN LA BASE DE DATOS");
		}
		else
		{
			System.out.println("La sede ya existe, no se cargaron los datos en la base");
		}
	}
	public static void cargarPais(Scanner in)
	{
		Pais p =cargarDatosPais(in);
		if(consultas.verificarQueElPaisNoExista(p.getNombre()))
		{
			consultas.ingresarPais(p);
			System.out.println("SE CARGO EXITOSAMENTE EL PAIS EN LA BASE DE DATOS");
		}
		else
		{
			System.out.println("El pais ya existia, no se pudo cargar");
		}
	}
	public static void mostrarTablaFutbolista()
	{
		System.out.println("Se muesta la tabla de los futbolistas");
		System.out.println("");
		consultas.obtenerTablaFutbolista();
	}
	public static void mostrarTablaSede()
	{
		System.out.println("Se muestra la tabla de la sede");
		consultas.obtenerTablaSede();
	}
	public static void mostrarTablaPais()
	{
		System.out.println("Se muestra la tabla de los paises");
		consultas.obtenerTablaPais();
	}
	public static Futbolista cargarDatosFutbolista(Scanner in)
	{
		System.out.println("Empieza la carga del nuevo futbolista");
		Futbolista f = new Futbolista();
		System.out.println("Se muestra como recordatorio los futbolistas ya ingresados");
		consultas.obtenerTablaFutbolista();
		System.out.println("");
		System.out.println("TENER EN CUENTA: El valor tiene que ser de tipo alfa numerico ");
		System.out.print("Ingrese el nombre del futbolista  ");
		f.setNombre(in.next());
		System.out.println("TENER EN CUENTA: El valor tiene que ser de tipo alfa numerico ");
		System.out.print("Ingrese el apellido del futbolista ");
		f.setApellido(in.next());
		System.out.println("TENER EN CUENTA: El valor tiene que ser de tipo numerico ");
		System.out.print("Ingrese el documento de identidad ");
		f.setDocIdentidad(in.next());
		System.out.println("TENER EN CUENTA: El valor tiene que ser de tipo  numerico ");
		System.out.print("Ingrese el telefono del futbolista ");
		f.setTelefono(in.next());
		System.out.println("TENER EN CUENTA: El valor tiene que ser de tipo alfa numerico ");
		System.out.print("Ingrese el email del futbolista  ");
		f.setEmail(in.next());
		System.out.println();
		System.out.println("Se muestran los paises a forma de recordatorio");
		consultas.obtenerTablaPais();
		System.out.println();
		System.out.println("TENER EN CUENTA: El valor tiene que ser de tipo numerico ");
		System.out.print("Ingrse uno de los id disponibles para pais ");
		f.setPais(in .nextInt());
		System.out.println("Datos del futbolista");
		System.out.print(f.getNombre()+" " +f.getApellido()+" "+f.getDocIdentidad()+" "+f.getTelefono()+" "+f.getEmail()+" "+f.getPais());
		System.out.println();
		consultas.obtenerTablaPais();
		System.out.print("Los datos son correctos? Responda si o no ");
		String rta = in.next();
		if(rta.equals("si"))
		{
			return f;
		}else
		{
			System.out.println("los datos no son correctos, no se guardo el futbolista en la tabla");
			return null;
		}
	}
	public static Sede cargarDatosSede(Scanner in)
	{
		System.out.println("Empieza la carga de los datos de la sede");
		Sede s = new Sede();
		System.out.println("Se muestran como recordatorio las sedes ya cargadas");
		consultas.obtenerTablaSede();
		System.out.println("");
		System.out.println("TENER EN CUENTA: El valor tiene que ser de tipo alfa numerico ");
		System.out.print("Ingrese el nombre de la sede ");
		s.setNombre(in.next());
		System.out.println("TENER EN CUENTA: El valor tiene que ser de tipo numerico ");
		System.out.print("Ingrese la capacidad de la sede ");
		s.setCapacidad(in.nextInt());
		System.out.println("Se muestran los paises con sus respectivos id en forma de ayuda");
		System.out.println("");
		consultas.obtenerTablaPais();
		System.out.println("TENER EN CUENTA: El valor tiene que ser de tipo numerico ");
		System.out.print("Ingrese el id del pais ");
		s.setPais(in.nextInt());
		return s;
	}
	public static Pais cargarDatosPais(Scanner in)
	{
		System.out.println("Empieza la carga de los datos del Pais");
		Pais p = new Pais();
		System.out.println("Se muestra como recordatorio los paises ya cargados");
		consultas.obtenerTablaPais();
		System.out.println("");
		System.out.println("TENER EN CUENTA: El valor tiene que ser de tipo alfa numerico ");
		System.out.print("Ingrese el nombre del Pais ");
		p.setNombre(in.next());
		System.out.println("TENER EN CUENTA: El valor tiene que ser de tipo alfa numerico");
		System.out.print("Ingrese el idioma del pais ");
		p.setIdioma(in.next());
		return p;
		
	}
}
